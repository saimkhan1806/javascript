
// ======================================
// Question 1
// ======================================
// var a = 10;
// ++a;

// document.write(` ++value is${a} <br>`)

// a++
// document.write(`value++ is${a} <br>`)

// --a;
// document.write(` valu--a is${a}<br>`)

// a--;
// document.write(` valu a-- is${a} <br>`)


// ======================================
// Question 2
// ======================================
var a = 2 
var b = 1 
// --a;
// --a - --b;
// --a - --b + ++b;
// --a - --b + ++b + b--;

// function main(){

//     let name = prompt("ente  your name")
//     let age = prompt("ente  your name")

//     document.write(`Hello I'm  ${name} Welcome to our progam age is ${age}`)
// }
// main(name)

// function juicer(fruit){
//     console.log("pass" + fruit+ "tis")
//     console.log("pass" + fruit+ "tis")
// }
// juicer('apple  ango')


// ======================================
// Question 3
// ======================================



// function greetUser(){

//     var userName= prompt("ente tthe name");

//     if(userName !== null && userName !== ""){
//         document.write(`hello ${userName} I am developer`)
//     }
//     else{
//         document.write(`better luck net time`)
//     }
// }

// ======================================
// Question 4
// ======================================
