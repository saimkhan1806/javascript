var age = 18;
alert( 'my age is ' + age)
var visits = 14;
alert("you have visited this site " + visits + " times")
var birthYear = 2005;
alert( 'my birth year is ' + birthYear)
var nameVisiter = "john hilton" ;
var  product = '5 t-shirt'
var store = 'XYZ clothing '
alert ( ' Hy ' + nameVisiter + ' you ordered ' + product + ' from ' + store); 