alert('error! please enter correct password');
alert('Welcome to JS land  \n Happy coding!')
