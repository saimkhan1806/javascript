// var num1 = 100;
// var num2 = 33;
// result = num1 + num2 ;
// document.write(`sum of ${num1} and ${num2} is =${result} <br> `);
// result = num1 - num2 ; 
// document.write(`sum of ${num1} - ${num2} is  =${result} <br> `);
// result = num1 * num2 ; 
// document.write(`sum of ${num1} * ${num2} is  =${result} <br> `);
// result = num1 / num2 ; 
// document.write(`sum of ${num1} / ${num2} is  =${result} <br> `);
// result = num1 % num2 ; 
// document.write(`sum of ${num1} % ${num2} is  =${result} <br> `);


var Variable;

document.write(`Value after variable declaration is:   ${Variable}  <br>`);

var Variable = 5

document.write(`intial value ${Variable} <br>`);

 Variable++ ;

 document.write(`   Value after increment ${Variable} <br>`)

 Variable += 7


 document.write(`value after addittion  ${ Variable}`)

 Variable--;

document.write(`intial value ${Variable} <br>`);
  

var remainder =  Variable % 3

document.write(`Remainder after dividing by 3 is: ${remainder}`);
