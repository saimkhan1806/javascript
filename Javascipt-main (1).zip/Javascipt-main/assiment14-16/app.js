// =================
// Question 1
// ================


// var student = [];
// student.push("Wasi")
// student.push("Khan")
// student.push("Taha")
// document.write(`${student}`)
// =================
// Question 2
// ================


// var student = [];
// student.push("Wasi")
// student.push("Khan")
// student.push("Taha")
// document.write(`${student}`)

// =================
// Question 3
// ================

var stringsArray = ["sttrings" ,"orrange","bananan"]
console.log(stringsArray)

// =================
// Question 4
// ================

var numArray = [12 , 13 ,76]
console.log(numArray)
numArray[0] = 14
console.log(numArray)
// =================
// Question 5
// ================

var boleanArray = [true ,false ,true]
console.log(boleanArray)
boleanArray[0] = false
console.log(boleanArray)
// =================
// Question 6
// ================

var mixedArray = [true ,'hello' ,12,]
console.log(mixedArray)
// =================
// Question 7   
// ================

// var education=['SSC','HSC','BCS', 'BS', 'BCOM','MS',"M.PHIL",'PHD']
// console.log(education)
// document.write(`qualifications in your ${education[0]}<br<br>>`)
// document.write(`qualifications in your ${education[1]}<br>`)
// document.write(`qualifications in your ${education[2]}<br>`)
// document.write(`qualifications in your ${education[3]}<br>`)
// document.write(`qualifications in your ${education[4]}<br>`)
// document.write(`qualifications in your ${education[5]}<br>`)
// document.write(`qualifications in your ${education[6]}<br>`)
// document.write(`qualifications in your ${education[7    ]}`)

// =================
// Question 8   
// ================

// var studentName =["wasi","imran",'bhutto']

// var score =[340,434,233]
// var totalMark = 500
// var calculatepercentage =[(score[0]/totalMark) * 100,
// (score[1]/totalMark) * 100,
// (score[2]/totalMark) * 100]
// console.log(`student name ${studentName[0]} score ${score[0]} percentage ${calculatepercentage[0]} %`)
// console.log(`student name ${studentName[1]} score ${score[1]} percentage ${calculatepercentage[1]} %`)
// console.log(`student name ${studentName[2]} score ${score[2]} percentage ${calculatepercentage[2]} %`)


// =================
// Question 9   
// ================
// var colour=["red","purple","blue"]
// console.log(colour)
// colour.push("black")
// console.log(colour)
// colour.push("white" , "orange")
// console.log(colour)
// colour.shift()
// console.log(colour)
// colour.pop()
// console.log(colour)

// =================
// Question 13   
// ================
let example = [];

newArray.push("example 1");
newArray.push("example 2");
newArray.push("example 3");

console.log(example[0]); 
console.log(example[1]); 
console.log(example[2]); 

// =================
// Question 14   
// ================
 var store=[]
store.unshift('store1')
store.unshift('store2')
store.unshift('store3')

console.log(store[0])
console.log(store[1])
console.log(store[2])






// ===================
// Question 15
// ====================
var phoneManufacturers = ["Apple", "Samsung", "Motorola", "Nokia", "Sony", "Haier"];

document.write("<select>");
document.write("<option value=''>Select a manufacturer</option>");

document.write("<option value='" + phoneManufacturers[0] + "'>" + phoneManufacturers[0] + "</option>");
document.write("<option value='" + phoneManufacturers[1] + "'>" + phoneManufacturers[1] + "</option>");
document.write("<option value='" + phoneManufacturers[2] + "'>" + phoneManufacturers[2] + "</option>");
document.write("<option value='" + phoneManufacturers[3] + "'>" + phoneManufacturers[3] + "</option>");
document.write("<option value='" + phoneManufacturers[4] + "'>" + phoneManufacturers[4] + "</option>");
document.write("<option value='" + phoneManufacturers[5] + "'>" + phoneManufacturers[5] + "</option>");

document.write("</select>");
