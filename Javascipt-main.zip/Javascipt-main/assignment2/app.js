var userName;
var fullName = 'Muhammad wasi';
var message = 'hello world';
var myAge = '18';
alert(message);
alert( 'my name is ' + fullName);
alert( 'I am ' + myAge + '  years old');
var pizza = 'PIZZA';
var pizz = 'PIZZ';
var piz = 'PIZ';
var pi = 'PI';
var p = 'P';
alert( pizza +'\n'+pizz+'\n'+piz+'\n'+pi+'\n'+p);
var email = 'example@gmail.com';
alert('My email is ' + email);
var book = 'smarter way to learn js ';
alert('I am trying to learn from a book called' + book);
var design = '“▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬”'
alert(design)



