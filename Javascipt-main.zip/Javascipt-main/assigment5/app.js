var num1 = 8
var num2 = 2

const result = num1*num2

console.log(result);