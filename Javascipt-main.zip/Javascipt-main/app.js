alert('welcome to my website')
alert('here you will get all of my assignment')