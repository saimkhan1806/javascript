// CHAPTER-5
//1: var num1 = +prompt("Enter number1");
//   var num2 = +prompt("Enter number2");
//   var result = num1 + num2;
//   document.write(result);

//2:  var num1 = +prompt("Enter number1");
//    var num2 = +prompt("Enter number2");
//    var result = num1- num2;
//    var result = num1 * num2;
//    var result = num1 /  num2;
//    var result = num1 % num2;
//    document.write(result); 

//3:  var num;
//    document.write("Value of variable after declaration is: " + num);
//    num = 3;
//    document.write("<br/><br/>Initial value: " + num);
//    num = ++num;
//    document.write("<br/><br/>Value after increment: " + num);
//    num = num + 7;
//    document.write("<br/><br/>Value after add (7): " + num);
//    num = --num;
//    document.write("<br/><br/>Value after decrement: " + num);
//    num = num % 3;
//    document.write("<br/><br/>Reminder is:" + num);

//4:  var movieTicketCost = 600;
//    var total = movieTicketCost * 5;
//    document.write("The cost to buy 5 movie tickets is: " + total + "PKR");


//5: document.write("Multipilication  table of 4")




//6:  var Tf = "53.6";
//    var Tc = (Tf-32)*5/9;
//    document.write(`${Tf}'F is in ${Tc}'C`);
//    var Tc = 20;
//    var Tf = (Tc*9/5) + 32;
//    document.write(`${Tc}'C is in ${Tf}'F ` );


//7: var priceItem1 = 500;
//   var priceItem2 = 900;
//   var orderQtyItem1 = +prompt("Enter oder of item1");
//   var orderQtyItem2 = +prompt("Enter order of item2");
//   var deliveryCharges = 2500;
//   document.write(
//     `<b>Shopping Cart Receipt</b>
//     <br/>Price of item 1 is ${priceItem1}
//     <br/> Price of item 2 is ${priceItem2}
//     <br/> Quantity of item 1 is ${orderQtyItem1}
//     <br/> Quantity of item 2 is ${orderQtyItem2}
//     <br/> Delivery charges = ${deliveryCharges}Rs
//     <br/> Total cost = ${priceItem1*orderQtyItem1 + priceItem2*orderQtyItem2 + deliveryCharges}Rs`
// );


//8:  var totalMarks = 600;
//    var obtainedMarks = +prompt("Enter Obtained marks");
//    var total = (obtainedMarks / totalMarks) * 100;
//    document.write(`Percentage: ${total.toFixed(2)}%`)


//9: var oneUSDollar = 104;
//   var oneSaudiRiyal = 28;
//   var total = (10 * oneUSDollar) + (25 * oneSaudiRiyal);
//   document.write(
//     `<b>Currency in PKR</b>
//     <br/><br/>Total amount in PKR: ${total} `
// )


//10: var num = 10;
//    num = num + 5;
//    num = num * 10;
//    num = num / 2;
//    document.write(num);


//11: var currYear = 2024;
//    var birthYear = 2004;
//    var total1 = currYear - birthYear;
//    var total2 = --currYear - birthYear;
//    document.write(`He is either ${total2} or ${total1} years old`)


//12: var radius = 10;
//    var circumference = 2 * 3.142 * radius;
//    var area = 3.142 * 10 * 10;
//    document.write(`Radius of circle: ${radius}<br/>Circumference of circle: ${circumference.toFixed(2)} <br/> Area of circle: ${area} `);


//13: var a = 10;
//    document.write(
//     `The value of a is: ${a} 
//     <br/><br/> The value of ++a is: 11 <br/> Now the value of a is: 11  
//     <br/><br/> The value of a++ is: 11 <br/> Now the value of a is: 12  
//     <br/><br/> The value of --a is: 11 <br/> Now the value of a is: 11
//     <br/><br/> The value of a-- is: 11 <br/> Now the value of a is: 10
//     `
// )


//14: var a = 2; 
//    var b = 1;
//    var result = --a - --b + ++b + b--;
//    document.write(
//     `a is ${a} <br/> b is ${b} <br/> result is ${result} `
// );


//15: var favSnack = "Super biscuits";
//    var currAge = 15;
//    var maxAge= 85;
//    var perDaySnacks = 2;
//    var toatl = (maxAge - currAge) * perDaySnacks;
//    document.write(
//     `<b>The Lifetime Supply Calculator</b>
//      <br/><br/>Favourite Snacks: ${favSnack}
//      <br/>Current Age: ${currAge} 
//      <br/>Maximun Age: ${maxAge} 
//      <br/>Snacks Per Day: ${perDaySnacks} 
//     <br/><br/>You will need ${toatl} ${favSnack} to last you until the ripe of old age of ${maxAge}`
// );
