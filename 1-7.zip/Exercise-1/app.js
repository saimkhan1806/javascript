//  CHAPTER-1
// 1: alert("Thanks for visiting our website")

// 2:  alert("Error! Please enter a valid passward.")

// 2:  alert("Welcome to JS Land...\n Happy Coding!");

// 3:  alert("Welcome to JS land");
//    alert("Happy Coding!\n <input type= 'checkbox' " + "/> Prevent this page from creating additional dialogs");

// 4:  alert("Hello.. I can run JS through my web Browser's console");
//    console.log("alert(" + "Hello.. I can run JS through my web Browser's console" + ")" );
