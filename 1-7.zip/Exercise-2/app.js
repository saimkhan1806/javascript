// CHAPTER-2
//1:  var userName = "ahmed1245";
//2:  var myName = "Muhammad Ahmed";
// document.write(userName + "<br/>" + myName);

//3:  var message = "Hello World";
//    alert(message);

//4   var name= "Muhammad Ahmed";
//    var num = 17;
//    var studies = "UBIT";
//    var diploma = "Web & App Develpoment";
//    alert(name);
//    alert(num);
//    alert(studies);
//    alert(diploma);

//6:  var num = 5;
//    var partnerName = "Alles";
//    var live = "SouthAsia";
//    var jobTitle = "WebDeveloper";
//    document.write("John " + jobTitle + " live in " + live +" with " + partnerName + " having " + num );

//7:  var email = "ahmedanis@gmail.com";
//    alert(email);

//8:  var book = "A Smarter way to leran javascript";
//    alert(book);

//9:  var name= "Muhammad Ahmed";
//    var num = 17;
//    var studies = "UBIT";
//    var diploma = "Web & App Develpoment";
//    document.write("Hi this is " + name + ", " + num + " years old " + " study BSCS from " + studies + " and doing " + diploma + " from SMIT");
//    alert("Hi this is " + name + ", " + num + " years old " + " study BSCS from " + studies + " and doing " + diploma + " from SMIT");
