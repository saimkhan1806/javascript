// CHAPTER-3
//1:   var age = 15;
//     alert(`I am ${age} years old`);

//2:  var noVisit = +prompt("Enter number of visit");
//    alert(`You have this page ${noVisit} times.`)

//3:  var birth = 2001;
//    document.write(`His birth year is ${birth}`);

//4:  var coustName = "Ahsan";
//    var productTitle = "Shirt";
//    var quantity = 4;
//    document.write(`${coustName} order (${quantity}) ${productTitle}s form Daraz online store.`)
