// CHAPTER-4
//1:  var name = "Hmaza ";
//    var suranme = " Ali ";
//    var skill = " Developer";
//    document.write(name + suranme + skill + ".");

//2:(Legal-var) var name = "Ali";
//              var fullName = "Ali mehar";
//              var $number = 50;
//              var place_of_Birth = "Pakistan";
                // var number$10 = 45;

//2:(Illegal-var) var full name = "";
//                var 3serial = "";
//                var #rollNumber = ;
//                var No:4 = ""
//                var birth-of-place = 1098;

//3:  var rules = " 'Rules for naming JS variables' ";
//    var rul1 = "$";
//    var rul2 = "_";
//    var rul3 = "lastName";
//    var rul4 = "";
//    var rul5 = "sensitive";
//    var rul6 = "Keyword";
//   document.write(
//     "a.A heading stating " + rules + "<br/><br/>b.Varible name can only contain (" + rul1 + " , " + rul2 + " , "+ 
//     " and " + rul3 + ") ." + "<br/> For example <b>$my_1stVariable</b>" + "<br/><br/>c. Variables must begin with a " + rul1 + " and " + rul2 + "." + "<br/>For example <b>$name,_name or name</b>" + "<br/><br/>d. Varaible names are case " + rul5 + "<br/><br/> e.Variable names sholld not be JS " + rul6
// );
